import React from 'react'

const Profile = ({char}) => {
  return (
        <div className=' profile bg-pink rounded-circle'>{char}</div>
    
  )
}

export default Profile